package com.baeldung.model;

public enum Modes {
    ALPHA, BETA;
}
