package com.baeldung.model;

public abstract class AbstractEntity {

    long id;
    public AbstractEntity(long id){
        this.id = id;
    }
    
}
