/**
 * 
 */
define({
    helloWorld : 'hola'
});