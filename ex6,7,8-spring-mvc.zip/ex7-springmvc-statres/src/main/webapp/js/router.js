/**
 * 
 */
Todos.Router.map(function() {
  this.resource('todos', { path: '/' });
});