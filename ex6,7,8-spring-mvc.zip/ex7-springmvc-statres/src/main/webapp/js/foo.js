function testing() {
    alert("Testing");
}