package com.baeldung.web.exception;

public class CustomerNotFoundException extends RuntimeException {

}
