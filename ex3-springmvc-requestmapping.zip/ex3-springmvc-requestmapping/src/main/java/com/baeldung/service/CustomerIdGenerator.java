package com.baeldung.service;

public interface CustomerIdGenerator {
    int generateNextId();
}

