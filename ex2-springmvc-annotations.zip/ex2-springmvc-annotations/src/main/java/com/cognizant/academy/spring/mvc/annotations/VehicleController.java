package com.cognizant.academy.spring.mvc.annotations;

import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(value = "/vehicles", method = RequestMethod.GET)
public class VehicleController {

    @CrossOrigin
    @ResponseBody
    @RequestMapping("/hello")
    public String hello() {
        return "Hello World!";
    }

//    @RequestMapping(params = {"test"}, headers =  {"unauthenticated"})
    @RequestMapping("/home")
    public String home() {
        return "home";
    }

    @PostMapping("/save")
    public void saveVehicle(@RequestBody Vehicle vehicle) {
    }

    @RequestMapping("/{id}")
    public String getVehicle(@PathVariable("id") long id) {
    	System.err.println("The id supplied was >>> " );
    	System.err.println( id);
        return "hello";
    }

    @RequestMapping
    public ModelAndView getVehicleByParam(@RequestParam("id") long id) {
        return new ModelAndView("hello", "message","The id that was read from the request param was " + Optional.of(id));
    }

    @RequestMapping("/buy")
    public Car buyCar(@RequestParam(defaultValue = "5") int seatCount) {
        return null;
    }

    @ExceptionHandler(IllegalArgumentException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public void onIllegalArgumentException(IllegalArgumentException exception) {
    }

    @PostMapping("/assemble")
    public void assembleVehicle(@ModelAttribute("vehicle") Vehicle vehicle) {
    }

    @ModelAttribute("vehicle")
    public Vehicle getVehicle() {
        return null;
    }

}
