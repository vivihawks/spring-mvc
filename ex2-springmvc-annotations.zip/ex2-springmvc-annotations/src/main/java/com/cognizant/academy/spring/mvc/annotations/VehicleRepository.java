package com.cognizant.academy.spring.mvc.annotations;

import org.springframework.stereotype.Repository;

@Repository
public class VehicleRepository {

}
