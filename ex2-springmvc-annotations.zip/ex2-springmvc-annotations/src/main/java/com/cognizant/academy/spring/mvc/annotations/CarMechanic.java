package com.cognizant.academy.spring.mvc.annotations;

import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

@Component
@Lazy
public class CarMechanic {

}
