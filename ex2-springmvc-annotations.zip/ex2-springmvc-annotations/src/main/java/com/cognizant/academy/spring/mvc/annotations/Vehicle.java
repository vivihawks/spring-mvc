package com.cognizant.academy.spring.mvc.annotations;

public interface Vehicle {
}
