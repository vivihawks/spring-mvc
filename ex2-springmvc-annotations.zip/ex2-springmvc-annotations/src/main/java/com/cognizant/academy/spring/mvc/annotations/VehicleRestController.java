package com.cognizant.academy.spring.mvc.annotations;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class VehicleRestController {

}
